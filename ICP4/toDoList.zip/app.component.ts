import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  // define list of items
  items= [];
  taskText: any;
  // Write code to push new item
  submitNewItem(str: string) {
    if (this.taskText != ""){
      var IDtoUse = this.items.length;
      alert(IDtoUse);
      this.items.push({id:IDtoUse,task: str,status:"Incopmlete"});
    }

  }

  // Write code to complete item
  completeItem(id: number) {
    this.items[id].status = "Completed!";
  }

  // Write code to delete item
  deleteItem(id: number) {
// @ts-ignore
    alert(id);
    var newList = [];
    for (var i = 0; i < this.items.length;i++){
      if (i != id) {
        var item = this.items[i];
        item.id = i;
        newList.push(item);
      }
    }
    this.items = newList;
  }

}
