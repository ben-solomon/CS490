import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  // define list of items
  items= [];
  taskText: any;
  // Write code to push new item
  submitNewItem(str: string) {
    if (this.taskText != ""){
      var IDtoUse = this.items.length;
      this.items.push({id:IDtoUse,task: str,status:"Incopmlete"});
    }

  }

  // Write code to complete item
  completeItem(id: number) {
    this.items[id].status = "Completed!";
  }

  // Write code to delete item
  deleteItem(id: number) {
// @ts-ignore
    var newArray = this.items.splice(id,1);
  }

}
