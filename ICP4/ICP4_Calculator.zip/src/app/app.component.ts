import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CalculatorICP';
  answer: any = '';
  first: any = 'empty';
  second = 0;
  operand: string;
  ButtonClick(j: any) {
    if (j == 111) {
      if (this.operand == 'add') {
        this.answer = this.first + this.second;
        this.first = 'empty';
        this.second = 0;
      } else if (this.operand == 'subtract') {
        this.answer = this.first - this.second;
        this.first = 'empty';
        this.second = 0;
      } else if (this.operand == 'mutli') {
        this.answer = this.first * this.second;
        this.first = 'empty';
        this.second = 0;
      } else if (this.operand == 'divide') {
        this.answer = this.first / this.second;
        this.first = 'empty';
        this.second = 0;
      } else {
        this.answer = '';
      }
    } else {
      if (this.first == 'empty') {
        this.first = j;
      } else {
        this.second = j;
      }
    }
  }
}
